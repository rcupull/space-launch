export const launches_for_pages: number = 10;

export const api_server = "https://spacelaunchnow.me/api/3.3.0";

export const url_launcher = api_server + "/launch/upcoming";
export const url_launch_details = api_server + "/launch";
